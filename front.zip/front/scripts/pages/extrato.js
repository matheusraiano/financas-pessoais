//
// ================================
// EXTRATO
// ================================
//
function inicializarExtrato() {
    console.log('Extrato carregado');
}