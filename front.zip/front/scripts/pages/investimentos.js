//
// ================================
// INVESTIMENTOS
// ================================
//
function inicializarInvestimentos() {
    console.log('Investimentos carregado');
}