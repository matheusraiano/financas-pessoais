//
// ================================
// NOTIFICAÇÕES
// ================================
//
function inicializarNotificacoes() {
    console.log('Notificações carregado');
}